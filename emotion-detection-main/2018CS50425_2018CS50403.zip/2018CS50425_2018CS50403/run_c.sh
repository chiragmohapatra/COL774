#!/bin/bash

python3 q_compe.py $1 $2 $3
