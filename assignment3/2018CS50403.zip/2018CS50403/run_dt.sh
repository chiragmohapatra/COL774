#!/bin/sh

python q1_decisiontree.py $1 $2 $3 $4 $5
# Example:
# ./run_dt.sh 1 "/home/vishal/A3/2016CSZ8119/train.csv" "/home/vishal/A3/2016CSZ8119/train.csv" "/home/vishal/A3/2016CSZ8119/train.csv" "/home/vishal/A3/2016CSZ8119/2016CSZ8119_dt.txt"
